#include<stdio.h>

int main()
{
	printf("helo");
	return 0;
}
